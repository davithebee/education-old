<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Koszyk</title>
</head>
<body>
<div id="main">
    <?php
        echo $_GET['products']."<br>";
        echo $_GET['product_amount']."<br>";
    ?>
</div>
</body>
</html>
